angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('menu.page1', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/page1.html',
        controller: 'page1Ctrl'
      }
    }
  })

  .state('menu.dESTAQUES', {
    url: '/page3',
    views: {
      'side-menu21': {
        templateUrl: 'templates/dESTAQUES.html',
        controller: 'dESTAQUESCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('menu.comidas', {
    url: '/page4',
    views: {
      'side-menu21': {
        templateUrl: 'templates/comidas.html',
        controller: 'comidasCtrl'
      }
    }
  })

  .state('menu.lanches', {
    url: '/page5',
    views: {
      'side-menu21': {
        templateUrl: 'templates/lanches.html',
        controller: 'lanchesCtrl'
      }
    }
  })

  .state('menu.serviOs', {
    url: '/page6',
    views: {
      'side-menu21': {
        templateUrl: 'templates/serviOs.html',
        controller: 'serviOsCtrl'
      }
    }
  })

  .state('menu.mapaDoNeoResidencial', {
    url: '/page7',
    views: {
      'side-menu21': {
        templateUrl: 'templates/mapaDoNeoResidencial.html',
        controller: 'mapaDoNeoResidencialCtrl'
      }
    }
  })

  .state('menu.promoO', {
    url: '/page9',
    views: {
      'side-menu21': {
        templateUrl: 'templates/promoO.html',
        controller: 'promoOCtrl'
      }
    }
  })

  .state('menu.casa', {
    url: '/page11',
    views: {
      'side-menu21': {
        templateUrl: 'templates/casa.html',
        controller: 'casaCtrl'
      }
    }
  })

  .state('menu.serviOsTec', {
    url: '/page12',
    views: {
      'side-menu21': {
        templateUrl: 'templates/serviOsTec.html',
        controller: 'serviOsTecCtrl'
      }
    }
  })

  .state('menu.cuidadoESaDe', {
    url: '/page13',
    views: {
      'side-menu21': {
        templateUrl: 'templates/cuidadoESaDe.html',
        controller: 'cuidadoESaDeCtrl'
      }
    }
  })

  .state('menu.contato', {
    url: '/page14',
    views: {
      'side-menu21': {
        templateUrl: 'templates/contato.html',
        controller: 'contatoCtrl'
      }
    }
  })

  .state('menu.informativo', {
    url: '/page15',
    views: {
      'side-menu21': {
        templateUrl: 'templates/informativo.html',
        controller: 'informativoCtrl'
      }
    }
  })

  .state('menu.cadastro', {
    url: '/page10',
    views: {
      'side-menu21': {
        templateUrl: 'templates/cadastro.html',
        controller: 'cadastroCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/side-menu21/page1')


});